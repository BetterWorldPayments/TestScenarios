import asyncio
from typing import Dict
from playwright.sync_api import sync_playwright
from playwright.sync_api import Page, TimeoutError
import time, json,  re, base64, requests, os,ast
from urllib.parse import urlparse
from datetime import datetime
from playwright.sync_api import sync_playwright, Browser, Page, Locator, TimeoutError as PlaywrightError,FrameLocator
import json, time, re, base64, requests, os, traceback
from functools import wraps
import uuid

file_path = 'operations_meta_data.json'

if os.getenv("HYPER") == "true":
    folder_name = os.path.abspath(__file__).split("/")[-2]
    file_path = f"extracted_hye_files/{folder_name}/operations_meta_data.json"

with open(file_path, 'r') as f:
    root_meta_data = json.load(f)
    # operations_meta_data = json.load(f)

def reload_metadata_root(switch_root="main_flow"):
    global operations_meta_data
    operations_meta_data = root_meta_data[switch_root]

def compare_screenshots(page:Page, before_screenshot:str, after_screenshot:str):

    compare_script = f"""
         (async function() {{
            try {{
                const beforeImage = 'data:image/png;base64,{before_screenshot}';
                const afterImage = 'data:image/png;base64,{after_screenshot}';
                const result = await new Promise((resolve) => {{
                    resemble(beforeImage).compareTo(afterImage).onComplete((data) => {{
                        resolve(data.misMatchPercentage);
                    }});
                }});
                return Math.ceil(result);
            }} catch (error) {{
                return -1; 
            }}
        }})();
        """
    result = page.evaluate(compare_script)

    if isinstance(result, float):
        return int(result)
    elif isinstance(result, int):
        return result
    else:
        print("Unexpected comparison result:", result)
        return -1 


class Heal:
    def __init__(self, operation_idx: str, page: Page):
        self.operation_idx = operation_idx
        self.page: Page = page
        self.current_action: dict = operations_meta_data[operation_idx]
        self.prev_actions: list[dict] = []
        self.tagified_image: str = ""
        self.xpath_mapping: dict = {}
        self.tags_description: dict = {}
        self.test_id: str = os.getenv('TEST_ID', '')
        self.username: str = os.getenv('LT_USERNAME', '')
        self.accesskey: str = os.getenv('LT_ACCESS_KEY', '')
        self.commit_id: str = os.getenv('COMMIT_ID', '')
        self.org_id: int = int(os.getenv('REQUEST_ID', '0'))
        self.page_source: str = ""
        self.code_export_id:str = uuid.uuid4().hex[:16]
        self.automind_url = os.environ.get('AUTOMIND_URL', 'https://kaneai-api.lambdatest.com')
        
    def resolve(self) -> requests.Response:
        attempt = 1
        max_attempt = 2

        while (max_attempt >= attempt):
            attempt += 1

            before_screenshot = base64.b64encode(self.page.screenshot(type="jpeg", full_page=True)).decode('utf-8')        
            self.page.evaluate("tagifyWebpage()")

            xpath_mapping = self.page.evaluate("fetchJsonData('JSONOutput')")
            self.xpath_mapping = json.loads(xpath_mapping)

            tags_description = self.page.evaluate("fetchJsonData('descOutput')")
            self.tags_description = json.loads(tags_description)

            self.tagified_image = self.page.screenshot(type="jpeg", full_page=True)

            clear_script = "annotations = []; JSONOutput = {}; nodeData = {};"
            untagify_script = "removeTags();"
            self.page.evaluate(f"{untagify_script} {clear_script}")

            payload = json.dumps({
                "code_export_id": self.code_export_id,
                "username": self.username,
                "org_id": self.org_id,
                "commit_id": self.commit_id,
                "current_action": self.current_action,
                "tagified_image": base64.b64encode(self.tagified_image).decode('utf-8'),
                "xpath_mapping": self.xpath_mapping,
                "tags_description": self.tags_description,
                "accesskey": self.accesskey,
                "test_id": self.test_id
            })

            headers = {'Content-Type': 'application/json'}
            print("Heal Resolve... code_export_id:", self.code_export_id)
            response = requests.request("POST", url=f"{self.automind_url}/heal/resolve", headers=headers, data=payload)

            after_screenshot = base64.b64encode(self.page.screenshot(type="jpeg", full_page=True)).decode('utf-8')
            mismatch_percentage = compare_screenshots(page = self.page, before_screenshot = before_screenshot, after_screenshot = after_screenshot)

            if mismatch_percentage >= 2:
                print("Retrying due to visual mismatch of ", mismatch_percentage, "%...")
                time.sleep(2)
                continue
            else:
                return response
            
        return response

    def list_xpaths(self) -> requests.Response:
        attempt = 1
        max_attempt = 2

        while (max_attempt >= attempt):
            attempt += 1

            before_screenshot = base64.b64encode(self.page.screenshot(type="jpeg", full_page=True)).decode('utf-8')

            if "QUERY" in self.current_action['operation_type']:
                self.page.evaluate("tagifyWebpage(false, true)")
            else:
                self.page.evaluate("tagifyWebpage()")

            xpath_mapping = self.page.evaluate("fetchJsonData('JSONOutput')")
            self.xpath_mapping = json.loads(xpath_mapping)

            tags_description = self.page.evaluate("fetchJsonData('descOutput')")
            self.tags_description = json.loads(tags_description)

            self.page_source = self.page.evaluate("document.body.outerHTML")

            self.tagified_image = self.page.screenshot(type="jpeg", full_page=True)

            clear_script = "annotations = []; JSONOutput = {}; nodeData = {};"
            untagify_script = "removeTags();"
            self.page.evaluate(f"{untagify_script} {clear_script}")

            payload = json.dumps({
                "code_export_id": self.code_export_id,
                "current_action": self.current_action,
                "prev_actions": self.prev_actions,
                "xpath_mapping": self.xpath_mapping,
                "tagified_image": base64.b64encode(self.tagified_image).decode('utf-8'),
                "commit_id": self.commit_id,
                "test_id": self.test_id,
                "username": self.username,
                "accesskey": self.accesskey,
                "tags_description": self.tags_description,
                "org_id": self.org_id,
                "page_source": self.page_source
            })

            headers = {'Content-Type': 'application/json'}
            print("Heal list Xpath... code_export_id:", self.code_export_id)
            response = requests.request("POST", url=f"{self.automind_url}/heal/xpaths", headers=headers, data=payload)
            after_screenshot = base64.b64encode(self.page.screenshot(type="jpeg", full_page=True)).decode('utf-8')
            mismatch_percentage = compare_screenshots(page = self.page, before_screenshot = before_screenshot, after_screenshot = after_screenshot)

            if mismatch_percentage >= 2:
                print("Retrying due to visual mismatch of ", mismatch_percentage, "%...")
                time.sleep(2)
                continue
            else:
                return response
            
        return response
    
    def resolve_xpath(self, page: Page) -> requests.Response:
    # If operation type contains "QUERY", pass appropriate arguments to the script
        if "QUERY" in self.current_action['operation_type']:
            self.page.evaluate("tagifyWebpage(false, true)")
        else:
            self.page.evaluate("tagifyWebpage()")

    # Fetch JSON data using Playwright's evaluate method
        xpath_mapping = self.page.evaluate("fetchJsonData('JSONOutput')")
        self.xpath_mapping = json.loads(xpath_mapping)

        tags_description = self.page.evaluate("fetchJsonData('descOutput')")
        self.tags_description = json.loads(tags_description)

    # Get the page source (outerHTML of the body)
        self.page_source = self.page.evaluate("document.body.outerHTML")

    # Get a screenshot as a base64-encoded string
        self.tagified_image = self.page.screenshot(type="png", full_page=True, encoding="base64")

    # Clear and remove tags using the appropriate scripts
        clear_script = "annotations = []; JSONOutput = {}; nodeData = {};"
        untagify_script = "await removeTags();"
        self.page.evaluate(f"{untagify_script} {clear_script}")

    # Prepare the payload for the POST request
        payload = json.dumps({
            "code_export_id": self.code_export_id,
            "current_action": self.current_action,
            "xpath_mapping": self.xpath_mapping,
            "tagified_image": self.tagified_image,
            "commit_id": self.commit_id,
            "test_id": self.test_id,
            "username": self.username,
            "accesskey": self.accesskey,
            "tags_description": self.tags_description,
            "org_id": self.org_id,
            "page_source": self.page_source,
        })

        headers = {'Content-Type': 'application/json'}

        print("Heal Resolve Xpath... code_export_id:", self.code_export_id)

    # Make a POST request
        response = requests.post(url=f"{self.automind_url}/heal/resolve", headers=headers, data=payload)
        print("RESPONSE TEXT:", response.text)

        return response

    def textual_query(self, outer_html: str) -> requests.Response:
        self.page_source = outer_html
        
        payload = json.dumps({
            "code_export_id": self.code_export_id,
            "username": self.username,
            "org_id": self.org_id,
            "commit_id": self.commit_id,
            "current_action": self.current_action,
            "accesskey": self.accesskey,
            "test_id": self.test_id,
            "page_source": self.page_source
        })

        headers = {'Content-Type': 'application/json'}
        print("Heal textual query... code_export_id:", self.code_export_id)
        response = requests.request("POST", f"{self.automind_url}/heal/query", headers=headers, data=payload)

        return response

    def vision_query(self) -> requests.Response:
        attempt = 1
        max_attempt = 2

        while (max_attempt >= attempt):
            attempt += 1

            before_screenshot = base64.b64encode(self.page.screenshot(type="jpeg", full_page=True)).decode('utf-8')

            self.page.evaluate("tagifyWebpage(false, true)")

            tags_description = self.page.evaluate("fetchJsonData('descOutput')")
            self.tags_description = json.loads(tags_description)

            self.tagified_image = self.page.screenshot(type="jpeg", full_page=True)

            clear_script = "annotations = []; JSONOutput = {}; nodeData = {};"
            untagify_script = "removeTags();"
            self.page.evaluate(f"{untagify_script} {clear_script}")

            payload = json.dumps({
                "code_export_id": self.code_export_id,
                "current_action": self.current_action,
                "tagified_image": base64.b64encode(self.tagified_image).decode('utf-8'),
                "commit_id": self.commit_id,
                "test_id": self.test_id,
                "username": self.username,
                "accesskey": self.accesskey,
                "tags_description": self.tags_description,
                "org_id": self.org_id,
            })

            headers = {'Content-Type': 'application/json'}
            print("Heal vision query... code_export_id:", self.code_export_id)
            response = requests.request("POST", url=f"{self.automind_url}/heal/vision", headers=headers, data=payload)

            after_screenshot = base64.b64encode(self.page.screenshot(type="jpeg", full_page=True)).decode('utf-8')
            mismatch_percentage = compare_screenshots(page = self.page, before_screenshot = before_screenshot, after_screenshot = after_screenshot)

            if mismatch_percentage >= 2:
                print("Retrying due to visual mismatch of ", mismatch_percentage, "%...")
                time.sleep(2)
                continue
            else:
                return response
            
        return response

    def to_json(self):
        json_payload = {
            "code_export_id": self.code_export_id,
            "current_action": self.current_action,
            "prev_actions": self.prev_actions,
            "xpath_mapping": self.xpath_mapping,
            "tagified_image": self.tagified_image.decode('utf-8'),
            "commit_id": self.commit_id,
            "test_id": self.test_id,
            "username": self.username,
            "accesskey": self.accesskey,
            "tags_description": self.tags_description,
            "org_id": self.org_id,
            "page_source": self.page_source
        }
        with open("payload.json", "w") as f:
            json.dump(json_payload, f)


    


def retry_click(total_time, polling_time=0.5):
    def decorator(func):
        @wraps(func)
        def wrapper(element, page: Page, *args, **kwargs):
            start_time = time.time()
            while True:
                try:
                    return func(element, page, *args, **kwargs)
                except PlaywrightError as e:
                    elapsed_time = time.time() - start_time
                    if elapsed_time >= total_time:
                        # Try fallback mechanisms here if timeout occurs
                        print("Retry attempts exhausted. Attempting fallback methods...")
                        try:
                            # Attempt JavaScript click
                            element.evaluate("el => el.click()")
                            print("JavaScript click successful.")
                            return
                        except Exception as e:
                            raise TimeoutError(f"Could not click the element within {total_time} seconds and all fallback methods failed.") from e
                    print(f"PlaywrightError caught. Retrying in {polling_time} seconds...")
                    time.sleep(polling_time)
        return wrapper
    return decorator

@retry_click(total_time=15, polling_time=1)
def click(element, page: Page):
    element.click()

# Check if conditions are met using Playwright
def conditions_met(page: Page) -> bool:
    # Check if the document is fully loaded

    document_ready = page.evaluate("document.readyState==='complete'")

    # Inject code to track active API requests
    page.evaluate("""
    if (typeof window.activeRequests === 'undefined') {
        window.activeRequests = 0;
        (function(open) {
            XMLHttpRequest.prototype.open = function() {
                window.activeRequests++;
                this.addEventListener('readystatechange', function() {
                    if (this.readyState === 4) {
                        window.activeRequests--;
                    }
                }, false);
                open.apply(this, arguments);
            };
        })(XMLHttpRequest.prototype.open);
    }
    """)
    # Check if any API requests are in progress
    active_requests = page.evaluate("window.activeRequests;")
    
    # Return True only if both conditions are met
    return document_ready and active_requests == 0

def retry(page: Page, operation_idx: str):
    print("IN RETRY FUNCTION")
    print("CHECKING CONDITION")

    # Replace WebDriverWait with a manual wait loop in Playwright
    timeout = 180  # seconds
    polling_frequency = 1  # seconds

    start_time = time.time()
    while time.time() - start_time < timeout:
        if conditions_met(page):
            print("CONDITION MET")
            break
        time.sleep(polling_frequency)
    else:
        raise TimeoutError("Condition not met within the given timeout.")

    # Call the Heal class with the page object instead of the driver
    response = Heal(operation_idx, page).list_xpaths()

    if response.status_code == 200:
        response_dict = json.loads(response.text)
        xpaths = response_dict.get('xpaths')
        lambda_hooks(page, "Locator Autohealed")
        if xpaths and len(xpaths) > 0:
            return xpaths
        print("XPATHS FROM AUTOMIND: ", xpaths)
        return operations_meta_data[operation_idx]['locator']
    else:
        print("Error in Getting Xpaths")
        return operations_meta_data[operation_idx]['locator']




def find_element(page: Page, locators: list, operation_idx: str, max_retries: int = 2, current_retry: int = 0, shadow=None,path=""):    
    print("Finding element...")

    if current_retry >= max_retries:
        print("MAX RETRIES EXCEEDED")
        return None

    for locator in locators:
        try:
            if shadow:
                    xpath_parts = locator.split('/')
    
                    css_selectors = []
    
                    for part in xpath_parts:
                        if part.startswith('..'):
                            continue  # Ignore ".."
        
        # Extract tag name and index if present
                        if '[' in part and ']' in part:
                            tag_name = part[:part.index('[')]
                            index = part[part.index('[') + 1:part.index(']')]  # Get the index
                            css_selector = f'{tag_name}:nth-of-type({index}) '
                        else:
                            tag_name = part  # Get the tag name without index
                            css_selector = f'{tag_name} '  # No index, just the tag name
        
                        css_selectors.append(css_selector)

    # Join the path and the new CSS selectors
                    path = ' '.join([path] + css_selectors)
                    element = page.locator(path)
            else:
                element = page.locator(f'xpath={locator}')
            element.wait_for(state='visible')
            print("ELEMENT: ", element)
            print("OPERATION INDEX: ", operation_idx)
            print("ELEMENT IS VISIBLE")
            # Check if the element is interactable
            is_visible=element.evaluate('(el) => el.offsetWidth > 0 && el.offsetHeight > 0')
            is_enabled=element.evaluate('(el) => !el.disabled')
            if is_visible and is_enabled:
                print("ELEMENT IS INTERACTABLE")
                print("Element found using locator:", element)
            else:
                print("ELEMENT IS NOT INTERACTABLE, RETRYING...")
                continue  # Continue to the next locator if the element is not interactable
            return element  

        except:
            print("Unable to find element using locator:", locator, "\nSwitching to next locator...")
            continue  # Continue to the next locator if the element is not found
    
    # Retry if the element was not found with any of the locators
    locators = retry(page=page, operation_idx=operation_idx)
    
    if locators:
        return find_element(page, locators, operation_idx, max_retries, current_retry + 1, shadow=shadow)  # Retry with incremented attempt count
    
    return None  # Return None if no element was found or retry exhausted


def lambda_hooks(page: Page, argument: str):
    try:
        script = f'lambdatest_executor: {{"action": "stepcontext", "arguments": {{"data": "{argument}", "level": "info"}}}}'
        page.evaluate(script)
        print(f"\n{argument}")
    except:
        print(f"\n{argument}")


def perform_assertion(operand1, operator, operand2):
    try:
        if operand1 is None or operand2 is None:
            print("None value found in operands") 

        if operator == "==":
            assert operand1 == operand2, f"Expected {operand1} to equal {operand2}"
        elif operator == "!=":
            assert operand1 != operand2, f"Expected {operand1} to not equal {operand2}"
        elif operator == "true":
            assert operand1, f"Expected true, got {operand1}"
        elif operator == "false":
            assert not operand1, f"Expected false, got {operand1}"
        elif operator == "is_null":
            assert operand1 is None, "Expected operand to be None"
        elif operator == "not_null":
            assert operand1 is not None, "Expected operand to be not None"
        elif operator == "contains":
            assert operand2 in operand1, f"Expected {operand2} to be in {operand1}"
        elif operator == "not_contains":
            assert operand2 not in operand1, f"Expected {operand2} to not be in {operand1}"
        elif operator == ">":
            assert operand1 > operand2, f"Expected {operand1} to be greater than {operand2}"
        elif operator == "<":
            assert operand1 < operand2, f"Expected {operand1} to be less than {operand2}"
        elif operator == ">=":
            assert operand1 >= operand2, f"Expected {operand1} to be greater than or equal to {operand2}"
        elif operator == "<=":
            assert operand1 <= operand2, f"Expected {operand1} to be less than or equal to {operand2}"
        print("Assertion passed")
    except AssertionError as e:
        print(f"Assertion failed: {str(e)}")

def handle_unresolved_operations(operations_meta_data, operation_index, page):
    unresolved_operation = operations_meta_data[operation_index]
    agent = unresolved_operation['agent']
    if agent == "Vision Agent":
        timeout = 30  # seconds
        polling_frequency = 3  # seconds

        start_time = time.time()
        while time.time() - start_time < timeout:
            if conditions_met(page):
                print("CONDITION MET")
                break
            time.sleep(polling_frequency)
        else:
            raise TimeoutError("Condition not met within the given timeout.")

        healer = Heal(operation_index, page)  
        response = healer.resolve()
        response = response.json()
        response['locator'] = [response['xpath']]
        operations_meta_data[operation_index].update(response)

    with open(file_path, 'w') as f:
        json.dump(operations_meta_data, f, indent=4)

def string_to_float(input_string):
    if isinstance(input_string, float):
        return input_string
    return float(''.join(filter(lambda x: x.isdigit() or x == '.', input_string)))


def heal_query(page: Page, operation_index: str, outer_html: str):

    response = Heal(operation_index, page).textual_query(outer_html)
    response_dict = json.loads(response.text)

    if 'regex' in response_dict:
        regex_pattern = response_dict.get('regex')
        lambda_hooks(page, "Regex Autohealed")
        print("REGEX FROM AUTOMIND: ", regex_pattern)
        return regex_pattern
    elif 'error' in response_dict or response.status_code == 500:
        print("Error encountered, retrying...")
    else:
        print("Error in Getting Regex")
        return ""
    return ""

def get_vision_operation_wait_time(operation_index):
    default_wait_time = 5 * 1000  # 5 seconds in milliseconds
    max_additional_wait_time = 30 * 1000  # 30 seconds in milliseconds
    wait_time = 0

    try:
        # Extract explicit and implicit wait times
        explicit_wait = float(operations_meta_data.get(operation_index, {}).get('explicit_wait', 0))
        implicit_wait = float(operations_meta_data.get(operation_index, {}).get('implicit_wait', 0))
        
        wait_time = explicit_wait + implicit_wait

        # Get additional wait time based on the previous operation end time
        additional_wait = default_wait_time
        prev_op_index = str(int(operation_index) - 1)
        prev_op_end_time = operations_meta_data.get(prev_op_index, {}).get('operation_end', '')
        curr_op_start_time = operations_meta_data.get(operation_index, {}).get('operation_start', '')

        if prev_op_end_time and curr_op_start_time:
            try:
                time_diff = (
                    datetime.strptime(curr_op_start_time, "%Y-%m-%d %H:%M:%S.%f") -
                    datetime.strptime(prev_op_end_time, "%Y-%m-%d %H:%M:%S.%f")
                ).total_seconds() * 1000  # Convert to milliseconds
                
                if time_diff > additional_wait:
                    additional_wait = time_diff

                # Limit additional wait time
                additional_wait = min(additional_wait, max_additional_wait_time)
            except ValueError as date_error:
                print(f"Date parsing error: {date_error}")
        
        wait_time += additional_wait
    except Exception as error:
        print(f"Error getting wait time: {error}")
        wait_time += default_wait_time  # Add default wait time in case of error

    print(f"Vision Wait time: {wait_time} ms")
    return wait_time
def vision_query(page, operation_index: str):
    result = None

    try:
        time.sleep(get_vision_operation_wait_time(operation_index)/1000)
        response = Heal(operation_index, page).vision_query()
        print("RESPONSE TEXT: ", response.text)
        response = json.loads(response.text)

        if "error" in response:
            raise RuntimeError(f"Error in vision query: {response['error']}")

        result = response['vision_query']

        utility = operations_meta_data[operation_index].get('string_to_float', False)

        if utility:
            result = string_to_float(result)

    except Exception as e:
        time.sleep(operations_meta_data[operation_index]['retries_delay'])
        if not operations_meta_data[operation_index]['optional_flag']:
            raise e
        elif operations_meta_data[operation_index]['optional_flag']:
            print(f"Failed to execute visual_query . Error: {e}")
        print(f"Retrying visual_query due to Error: {str(e)[:50]}....")

    return result

def execute_js(user_js_code: str, page: Page) -> dict:
    try:
        lines_before_user_code = 2

        # Wrap the user's code to capture the return value and handle errors
        wrapped_js_code = f"""
        (function() {{
            try {{
                return (function() {{ {user_js_code} }})();
            }} catch(e) {{
                e.stack = e.stack.replace(/<anonymous>:(\\d+):/g, function(match, lineNumber) {{
                    lineNumber = parseInt(lineNumber) - {lines_before_user_code};
                    return '<anonymous>:' + lineNumber + ':';
                }});
                return {{error: e.stack}};
            }}
        }})();
        """

        # Execute the script on the page and return the result
        client_response_js = page.evaluate(f"() => {wrapped_js_code}")

        if isinstance(client_response_js, dict) and 'error' in client_response_js:
            # An error occurred during execution
            error_stack = client_response_js['error']
            lines = error_stack.split('\n')
            error_message = lines[0].strip()
            error_line = None

            # Extract the line number from the stack trace
            if len(lines) > 1:
                match = re.search(r'<anonymous>:(\d+):', lines[1])
                if match:
                    error_line = int(match.group(1))

            return {
                'value': '',
                'error': error_message,
                'line': error_line
            }
        else:
            # Successful execution
            try:
                # Attempt to serialize the return value
                json.dumps(client_response_js)
                if client_response_js is None or client_response_js == '':
                    client_response_js = "null"
                return {
                    'value': client_response_js,
                    'error': '',
                    'line': None
                }
            except (TypeError, OverflowError):
                # If serialization fails, convert the return value to a string
                return {
                    'value': str(client_response_js),
                    'error': '',
                    'line': None
                }
    except Exception as e:
        # Catch any other exceptions
        return {
            'value': '',
            'error': str(e),
            'line': None
        }

def replace_secrets(text: str) -> str:
    matches = re.findall(r'\{\{(.*?)\}\}', text)
    for match in matches:
        keys = match.split('.')
        if len(keys) == 3 and keys[0] == 'secrets':
            secret_value = os.getenv(keys[2], '')
            text = text.replace(f"{{{{{match}}}}}", secret_value)

    return text

def replace_secrets_in_dict(
    d: Dict[str, str]
) -> Dict[str, str]:

    new_dict = {}
    for k, v in d.items():
        replaced_key = replace_secrets(k)
        replaced_value = replace_secrets(v)
        if replaced_key == 'Authorization' and not replaced_value.startswith('Bearer'):
            username = replaced_value.split(':')[0]
            access_key = replaced_value.split(':')[1]
            replaced_value = f"Basic {base64.b64encode(f'{username}:{access_key}'.encode()).decode()}"
        new_dict[replaced_key] = replaced_value

    return new_dict


def execute_api(page:Page, method: str, url: str, headers: str, body: str, params: dict, timeout: int,verify:bool) -> dict:
    parsed_url = urlparse(url)
    if not all([parsed_url.scheme, parsed_url.netloc]):
        return {'status':400,'message':'Invalid URL'}
    if(url.startswith("wss://") or url.startswith("ws://")):
        return {'status':400,'message':'Websockets not supported'}
    for key in headers:
        if(headers[key]=='text/event-stream'):
            return {'status':400,'message':'Sse not supported'}
    start=time.time()
    try:
        if method.upper() == "GET":
            response = requests.get(url, headers=headers, params=params,timeout=timeout, proxies={"http":"http://127.0.0.1:22000", "https":"http://127.0.0.1:22000"},verify=verify)
        elif method.upper() == "POST":
            response = requests.post(url, headers=headers, data=body, params=params,timeout=timeout, proxies={"http":"http://127.0.0.1:22000", "https":"http://127.0.0.1:22000"},verify=verify)
        elif method.upper() == "PUT":
            response = requests.put(url, headers=headers, data=body, params=params,timeout=timeout, proxies={"http":"http://127.0.0.1:22000", "https":"http://127.0.0.1:22000"},verify=verify)
        elif method.upper() == "DELETE":
            response = requests.delete(url, headers=headers, params=params,timeout=timeout, proxies={"http":"http://127.0.0.1:22000", "https":"http://127.0.0.1:22000"},verify=verify)
        elif method.upper() == "PATCH":
            response = requests.patch(url, headers=headers, data=body,params=params,timeout=timeout, proxies={"http":"http://127.0.0.1:22000", "https":"http://127.0.0.1:22000"},verify=verify)
    except Exception as e:
        return {'status':400,'message':"API request failed " + str(e)}
    end=time.time()
    test_api_resp = {
        'status' : response.status_code,
        'headers' : response.headers,
        'cookies' : response.cookies,
        'body' : response.content,
        'time' : (end-start)*1000
    }
    checker=[]
    for key in test_api_resp:
        checker.append(key)
    for i in range(0,len(checker)):
        key=checker[i]
        try:
            json.dumps(test_api_resp[key])  # Try to serialize the value
        except (TypeError, ValueError):
            if isinstance(test_api_resp[key], bytes):
                test_api_resp["response_body"] = [test_api_resp[key].decode('utf-8')]
            test_api_resp[key] = list(test_api_resp[key]) 
            for i in range(0,len(test_api_resp[key])):
                    try:
                        json.dumps(test_api_resp[key][i])
                    except (TypeError, ValueError):
                        test_api_resp[key][i] = str(test_api_resp[key][i])
    return test_api_resp

def send_keys(element, page, value, timeout=100):
    # Click the element to focus
    element.click()

    # Wait for the focused element to be an input, textarea, or contenteditable
    focused_element = page.wait_for_function(
        """
        () => {
            const activeElement = document.activeElement;
            if (
                activeElement &&
                (activeElement.tagName.toLowerCase() === 'input' ||
                    activeElement.tagName.toLowerCase() === 'textarea' ||
                    activeElement.isContentEditable)
            ) {
                return activeElement;
            }
            return null;
        }
        """
    )

    if not focused_element:
        raise ValueError("Failed to find a valid input, textarea, or contenteditable field.")

    # Clear the input field
    page.evaluate(
        """
        (el) => {
            if (el.tagName.toLowerCase() === 'input' || el.tagName.toLowerCase() === 'textarea') {
                el.value = ''; // Clear for input or textarea
            } else if (el.isContentEditable) {
                el.textContent = ''; // Clear for contenteditable
            }
            el.click();
            el.dispatchEvent(new Event('input', { bubbles: true })); // Trigger input event
        }
        """,
        focused_element,
    )

    # Type the value with a delay to simulate typing and trigger suggestions
    page.type(":focus", value, delay=timeout)

    # Return the currently focused element as a locator
    locator = page.locator(":focus")
    return locator

def switchTab(context, index):
    pages = context.pages
    if len(pages) <= index:
        context.wait_for_event("page")
    pages = context.pages
    if index < len(pages):
        return pages[index]
    else:
        raise ValueError(f"Tab at index {index} does not exist.")
def xpath_to_css(value):
    xpath_parts = value.split('/')

    css_selectors = []

    for part in xpath_parts:
        if part.startswith(".."):
            continue  # Ignore ".."

        # Extract tag name and index if present
        if "[" in part and "]" in part:
            tag_name = part[:part.index("[")]
            index = part[part.index("[") + 1 : part.index("]")]
            css_selector = f"{tag_name}:nth-of-type({index})"
        else:
            tag_name = part  # Get the tag name without index
            css_selector = tag_name  # No index, just the tag name

        css_selectors.append(css_selector)

    return css_selectors

def ui_action(page, operation_index: str):
    if 'unresolved' in operations_meta_data[operation_index]:
        print("Resolving unresolved operation")
        handle_unresolved_operations(operations_meta_data, operation_index, page)
    max_retries = operations_meta_data[operation_index]['max_retries']
    if max_retries == 0:
        max_retries = 3

    action: str = operations_meta_data[operation_index]['operation_type']
    locators = operations_meta_data[operation_index].get('locator', None)
    frame_info = operations_meta_data[operation_index].get('frame', None)
    user_vars_list = operations_meta_data[operation_index].get('user_variables', '')
    
    for key, value in operations_meta_data[operation_index].items():
       if isinstance(value, str) and value.startswith("secrets."):
           env_var_name = value.split(".")[1]
           operations_meta_data[operation_index][key] = os.getenv(env_var_name, '')


    if user_vars_list != '':
        user_vars_list = json.loads(user_vars_list)

    if locators is not None and locators[0].startswith("[") and locators[0].endswith("]"):
        coordinates = locators[0]
    else:
        coordinates = None

    regex = None
    if 'regex_pattern' in operations_meta_data[operation_index]:
        regex_pattern = operations_meta_data[operation_index]['regex_pattern']
        regex = base64.b64decode(regex_pattern).decode("utf-8")
    html=""
    for attempts in range(1, max_retries + 2):
        try:
            if operations_meta_data[operation_index]['explicit_wait']:
                time.sleep(operations_meta_data[operation_index]['explicit_wait'])

            # Handle frames and shadow DOM elements
            shadow = None
            path=""
            if frame_info and frame_info != "":
                frames = json.loads(frame_info)
                for frame in frames:
                    key, value = list(frame.items())[0]
                    if isinstance(value, list):
                        for i in range(len(value)):
                            try:
                                css_selectors = xpath_to_css(value[i])  # Assuming xpath_to_css is defined elsewhere
                                path = ' '.join([path, *css_selectors])
                                element_handle = page.locator(path).element_handle()
                                page = element_handle.content_frame()
                                shadow = None
                                path = ""
                                break
                            except Exception as error:
                                continue
                        continue
                    
    
                    css_selectors=xpath_to_css(value)

    # Join the path and the new CSS selectors
                    path = ' '.join([path] + css_selectors)
                    if key == "iframe":
                        page = page.frame_locator(path)
                        shadow = None
                        path=""
                    elif key == "shadow":
                        shadow="1"
            print("path: ", path)
            element = None
            if locators and coordinates is None:
                element = find_element(page, locators, operation_index,shadow=shadow,path=path)
            print("ELEMENT: ", element)
            # Perform actions based on the operation type
            scroll_sleep_time=1
            time.sleep(0.2)
            if 'click' in action.lower():
                if operations_meta_data[operation_index].get('mi_keypress_info', None) is not None:
                    value = json.loads(operations_meta_data[operation_index]['mi_keypress_info'])
                    for key_dict in value.get("true_keys", []):
                        key = list(key_dict.keys())[0].split("Key")[0].upper()
                        if key == "META":
                            key = "CONTROL"
                        page.keyboard.down(key)
                    element.click()
                    print(element)
                    for key_dict in value.get("true_keys", []):
                        key = list(key_dict.keys())[0].split("Key")[0].upper()
                        page.keyboard.up(key)
                else:
                    if coordinates:
                        x = float(coordinates.split(",")[0].replace("[", ""))
                        y = float(coordinates.split(",")[1].replace("]", ""))
                        page.mouse.click(x, y)
                    else:
                        click(element, page)

            elif action.lower() == 'hover':
                if coordinates:
                    x = float(coordinates.split(",")[0].replace("[", ""))
                    y = float(coordinates.split(",")[1].replace("]", ""))
                    page.mouse.move(x, y)
                else:
                    element.hover()

            elif action.lower() == 'api':
                method = operations_meta_data[operation_index]["method"]
                url = operations_meta_data[operation_index]["url"]
                headers = operations_meta_data[operation_index]["headers"]
                headers = replace_secrets_in_dict(headers)
                body = operations_meta_data[operation_index]["body"]
                params = operations_meta_data[operation_index]["params"]
                timeout = operations_meta_data[operation_index]["timeout"]
                verify = operations_meta_data[operation_index]["verify"]
                response = execute_api(page, method, url, headers, body, params, timeout,verify)

                return response
            elif action.lower() == 'type' or action.lower() == 'input':
                element.click()
                time.sleep(1)
                element.evaluate("el=>{el.value=''};")
                if frame_info and frame_info != "":
                    type_pattern = element.get_attribute('pattern')
                    if type_pattern and '[0-9]{2}' in type_pattern:
                        send_keys(element, page, operations_meta_data[operation_index]['value'], delay=500)
                    else:
                        send_keys(element, page, operations_meta_data[operation_index]['value'])
                else:
                    send_keys(element, page, operations_meta_data[operation_index]['value'])

            elif action.lower() == 'search':
                element.click()
                element.evaluate("el=> el.value=''")
                send_keys(element, page, operations_meta_data[operation_index]['value']).press("Enter")
            elif action.lower() == 'enter':
                element.press("Enter")

            elif action.lower() == 'clear':
                current_value = element.input_value()
                if current_value:
                    n = len(current_value)
                    for i in range(n):
                        element.press("Backspace")
                # if element has contenteditable attribute
                if element.evaluate("el=>el.isContentEditable"):
                    element.fill("")

            elif action.lower() == 'scroll_element_top_bottom':
                if operations_meta_data[operation_index]['scroll_direction'] == 'down':
                    page.evaluate('window.scrollTo(0, document.body.scrollHeight);')
                elif operations_meta_data[operation_index]['scroll_direction'] == 'up':
                    page.evaluate('window.scrollTo(0, -document.body.scrollHeight);')
                elif operations_meta_data[operation_index]['scroll_direction'] == 'left':
                    page.evaluate('window.scrollTo(-document.body.scrollWidth,0);')
                elif operations_meta_data[operation_index]['scroll_direction'] == 'right':
                    page.evaluate('window.scrollTo(document.body.scrollWidth,0);')  
                time.sleep(scroll_sleep_time)      

            elif action.lower() == 'scroll_element_by_pixels':
                scroll_value = int(operations_meta_data[operation_index].get('scroll_value',100))
                if operations_meta_data[operation_index]['scroll_direction'] == 'up':
                    page.evaluate(f"window.scrollBy(0, -{scroll_value});")
                elif operations_meta_data[operation_index]['scroll_direction'] == 'down':
                    page.evaluate(f"window.scrollBy(0, {scroll_value});")
                elif operations_meta_data[operation_index]['scroll_direction'] == 'left':
                    page.evaluate(f"window.scrollBy(-{scroll_value},0);")
                elif operations_meta_data[operation_index]['scroll_direction'] == 'right':
                    page.evaluate(f"window.scrollBy({scroll_value},0);")
                time.sleep(scroll_sleep_time)
            elif action.lower() == 'scroll_element_by_percentage':
                total_height = page.evaluate("document.body.scrollHeight")
                scroll_pixels = total_height * (int(operations_meta_data[operation_index].get('scroll_value',10)) / 100)
                if operations_meta_data[operation_index]['scroll_direction'] == 'up':
                    page.evaluate(f'window.scrollBy(0, -{scroll_pixels});')
                elif operations_meta_data[operation_index]['scroll_direction'] == 'down':
                    page.evaluate(f"window.scrollBy(0, {scroll_value});")
                elif operations_meta_data[operation_index]['scroll_direction'] == 'left':
                    page.evaluate(f"window.scrollBy(-{scroll_value},0);")
                elif operations_meta_data[operation_index]['scroll_direction'] == 'right':
                    page.evaluate(f"window.scrollBy({scroll_value},0);")
                time.sleep(scroll_sleep_time)

            elif action.lower() == 'scroll_element_by_times':
                scroll_value = int(operations_meta_data[operation_index].get('scroll_value', 100))
                if operations_meta_data[operation_index]['scroll_direction'] == 'down':
                    page.evaluate(f"scroll_height = {scroll_value} * window.innerHeight; window.scrollBy(0, scroll_height);")
                elif operations_meta_data[operation_index]['scroll_direction'] == 'up':
                    page.evaluate(f"scroll_height = {scroll_value} * window.innerHeight; window.scrollBy(0, -scroll_height);")
                elif operations_meta_data[operation_index]['scroll_direction'] == 'down':
                    page.evaluate(f"scroll_width = {scroll_value} * window.innerWidth; window.scrollBy(-scroll_width,0);")
                elif operations_meta_data[operation_index]['scroll_direction'] == 'right':
                    page.evaluate(f"scroll_width = {scroll_value} * window.innerWidth; window.scrollBy(scroll_width,0);")
                time.sleep(scroll_sleep_time)
            elif action.lower() == 'refresh':
                page.reload()

            elif action.lower() == 'open':
                page.goto(operations_meta_data[operation_index]['url'])

            elif action.lower() == 'scroll_top_bottom':
                if operations_meta_data[operation_index]['scroll_direction'] == 'up':
                    page.evaluate("window.scrollTo(0, -document.body.scrollHeight)")
                elif operations_meta_data[operation_index]['scroll_direction'] == 'down':
                    page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
    
                time.sleep(scroll_sleep_time)
            elif action.lower() == 'scroll_pixels':
                scroll_value = int(operations_meta_data[operation_index]['scroll_value'])
                if operations_meta_data[operation_index]['scroll_direction'] == 'up':
                    page.evaluate(f"window.scrollBy(0, -{scroll_value})")
                elif operations_meta_data[operation_index]['scroll_direction'] == 'down':
                    page.evaluate(f"window.scrollBy(0, {scroll_value})")
                time.sleep(scroll_sleep_time)
            elif action.lower() == 'scroll_percentage':
                total_height = page.evaluate("document.body.scrollHeight")
                scroll_value_percentage = int(operations_meta_data[operation_index]['scroll_value'])
                scroll_pixels = total_height * (scroll_value_percentage / 100)
    
                if operations_meta_data[operation_index]['scroll_direction'] == 'up':
                    page.evaluate(f"window.scrollBy(0, -{scroll_pixels})")
                elif operations_meta_data[operation_index]['scroll_direction'] == 'down':
                    page.evaluate(f"window.scrollBy(0, {scroll_pixels})")
                time.sleep(scroll_sleep_time)

            elif action.lower() == 'scroll_times':
                scroll_value = int(operations_meta_data[operation_index]['scroll_value'])
                if operations_meta_data[operation_index]['scroll_direction'] == 'up':
                    page.evaluate(f"""
                        scroll_height = {scroll_value} * window.innerHeight;
                        window.scrollBy(0, -scroll_height);
                    """)
                elif operations_meta_data[operation_index]['scroll_direction'] == 'down':
                    page.evaluate(f"""
                        scroll_height = {scroll_value} * window.innerHeight;
                        window.scrollBy(0, scroll_height);
                    """)
                time.sleep(scroll_sleep_time)

            elif action.lower() == 'navigate':
                if operations_meta_data[operation_index]['navigation_direction'] == 'back':
                    page.go_back()
                elif operations_meta_data[operation_index]['navigation_direction'] == 'forward':
                    page.go_forward()
                    
            elif action.lower() == 'wait':
                time.sleep(int(operations_meta_data[operation_index]['value']))

            elif action.lower() == "scroll_to":
                element.evaluate("el => el.scrollIntoView({block: 'center'});")

            elif action.lower() == "scroll":
                value = json.loads(operations_meta_data[operation_index].get('mi_scroll_info', '{}'))
                for scroll_target, scroll_dict in value.items():
                    if scroll_target == "document":
                        window_scroll_script = f"window.scrollTo({scroll_dict['windowScrollX']}, {scroll_dict['windowScrollY']});"
                        page.evaluate(window_scroll_script)
                    else:
                        element_scroll_script = f"arguments[0].scrollLeft = {scroll_dict['scrollLeft']}; arguments[0].scrollTop = {scroll_dict['scrollTop']};"
                        page.evaluate(element_scroll_script, page.locator(f'xpath={scroll_target}'))

            elif action.lower() == "sendkeys":
                key = operations_meta_data[operation_index]['key'].split(".")[1].upper()
                page.keyboard.press(key)

            elif action.lower() == "select":
                option = operations_meta_data[operation_index]['value']
                select_option = option.split("::")

                if len(select_option) == 1:
                    value = select_option[0]
                    text = select_option[0]
                else:
                    value, text = select_option[0], select_option[1]

                try:
                    element.select_option(value=value)
                except:
                    element.select_option(label=text)

            elif action.lower() == "textual_query":
                if element is None:
                    print("Element not found in query")
                    raise ValueError("Element not found")

                print("element",element)
                html=element.evaluate("el => el.outerHTML").replace('"', "'").replace("\n", "")

                if not html:
                    print("Outer HTML not found in query")
                    raise ValueError("Outer HTML not found")

                match = re.search(fr"{regex}", html)
                if match:
                    result = match.group(1)
                else:
                    result = None
                if result is None:
                   raise ValueError("Regex not found")
                if(operations_meta_data[operation_index]['string_to_float']):
                    result = string_to_float(result)    
                return result

            elif action.lower() == "script":
                user_js_code = operations_meta_data[operation_index]['js_snippet']
                js_script_resp = execute_js(user_js_code=user_js_code, page=page)
                if "error" in js_script_resp and js_script_resp["error"]:
                    raise Exception(js_script_resp)
                if "value" in js_script_resp and js_script_resp["value"] != "null":
                    user_vars_list[0]["variable_value"] = js_script_resp["value"]

            else:
                raise ValueError(f"Invalid action: {action}")

            
            break  # Break out of retry loop if successful

        except Exception as e:
            error_message = str(e)
            if action.lower() == "script":
                break

            time.sleep(operations_meta_data[operation_index]['retries_delay'])

            if attempts == max_retries +1 and not operations_meta_data[operation_index]['optional_flag']:
                raise e
            
            elif attempts == max_retries+1 and operations_meta_data[operation_index]['optional_flag']:
                print(f"Failed to execute action: {action} on locator: {operations_meta_data[operation_index]['locator']}. Error: {e}")
                break
            
            if error_message == "Element not found" or error_message == "Outer HTML not found":
                print("Element not found. Autohealing locators...")
                locators = retry(page=page, operation_idx=operation_index)  # Adjust as needed

            elif error_message == "Regex not found":
                print("Regex not found. Autohealing regex...")
                sub = heal_query(page=page, operation_index=operation_index, outer_html=html)
                if sub!="" :
                    regex = sub
            print(f"Retrying due to Error: {error_message[:50]}....")
                    
