
import json
import os
import urllib
import subprocess
from playwright.sync_api import sync_playwright
from UIActions import ui_action, lambda_hooks, vision_query, perform_assertion, string_to_float, reload_metadata_root, switchTab


username = os.getenv("LT_USERNAME")
access_key = os.getenv("LT_ACCESS_KEY")

capabilities = {
    'browserName': 'Chrome',
    'browserVersion': '114',
    'LT:Options': {
        'platform': 'linux',
        'user': username,
        'accessKey': access_key,
        'video': True,
        'resolution': '1920x1080',
        'network': True,
        'build': "82ba01fb-7d83-4746-8f0f-4f034434ae34",
        'project': "Auteur-Code-Export",
        'name': "Request_a_Quote_from_Better_World",
        'w3c': True,
        'plugin': "python-python",
        'visual': True,
        'console': True,
        'tms.tc_id': 'TC-3',
        'loadExtensions': [os.getenv("EXTENSION")],
        
    }
}

def set_test_status(page, status, remark):
    page.evaluate("_ => {}",
                  "lambdatest_action: {\"action\": \"setTestStatus\", \"arguments\": {\"status\":\"" + status + "\", \"remark\": \"" + remark + "\"}}")


def enable_extension_for_incognito(context):
    page = context.new_page()
    page.goto("chrome://extensions/")
    page.locator("cr-button#detailsButton").first.click()
    page.locator("#allow-incognito #bar").click()
    page.close()


def run(playwright):
    playwright_version = subprocess.getoutput('playwright --version').strip().split(" ")[1]
    capabilities['LT:Options']['playwrightClientVersion'] = playwright_version

    # Connect to the LambdaTest Playwright Hub
    lt_cdp_url = f'wss://cdp.lambdatest.com/playwright?capabilities=' + urllib.parse.quote(json.dumps(capabilities))
    browser = playwright.chromium.connect(lt_cdp_url, timeout=120000)
    context = browser.new_context(viewport={'width': 1512, 'height': 982})

    enable_extension_for_incognito(context)

    page = context.new_page()
    reload_metadata_root()

    try:

        # go to 'www.betterworld.nl'
        lambda_hooks(page, "go to 'www.betterworld.nl'")
        ui_action(page=page, operation_index=str(0))

        # Scroll down in the scrollable element
        lambda_hooks(page, "Scroll down in the scrollable element")

        # Type 'martijn.wilbrink@betterworld.nl' in the input box
        lambda_hooks(page, "Type 'martijn.wilbrink@betterworld.nl' in the input box")
        ui_action(page=page, operation_index=str(2))

        # Click on 'Send me a quote' button
        lambda_hooks(page, "Click on 'Send me a quote' button")
        ui_action(page=page, operation_index=str(3))

        # type 'Martijn' in input field
        lambda_hooks(page, "type 'Martijn' in input field")
        ui_action(page=page, operation_index=str(4))

        # type 'Wilbrink' in input box 'Last Name'
        lambda_hooks(page, "type 'Wilbrink' in input box 'Last Name'")
        ui_action(page=page, operation_index=str(5))

        # type '0621512225' in input box 'Phone'
        lambda_hooks(page, "type '0621512225' in input box 'Phone'")
        ui_action(page=page, operation_index=str(6))

        # type 'Better World' in input box for 'Organization'
        lambda_hooks(page, "type 'Better World' in input box for 'Organization'")
        ui_action(page=page, operation_index=str(7))

        # Type 'www.betterworld.nl' in the input box for 'Website'
        lambda_hooks(page, "Type 'www.betterworld.nl' in the input box for 'Website'")
        ui_action(page=page, operation_index=str(8))

        # Click the middle option of 'Expected Monthly Volume'
        lambda_hooks(page, "Click the middle option of 'Expected Monthly Volume'")
        ui_action(page=page, operation_index=str(9))

        # Click on the 'Send' button
        lambda_hooks(page, "Click on the 'Send' button")
        ui_action(page=page, operation_index=str(10))

        # Click the 'Sluiten' button
        lambda_hooks(page, "Click the 'Sluiten' button")
        ui_action(page=page, operation_index=str(11))

        set_test_status(page, "passed", "passed")
    except Exception as e:
        print("Error:: ", e)
        set_test_status(page, "failed", str(e))
    finally:
        browser.close()

with sync_playwright() as playwright:
    run(playwright)
